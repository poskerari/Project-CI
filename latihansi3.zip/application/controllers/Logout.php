<title>Logout </title>
<?php
session_start();
session_destroy();
?>
	<td><img src="aset/image/bear.gif"></td>
	<td><img src="aset/image/bear.gif"></td>
	<td><img src="aset/image/bear.gif"></td>
	<td><img src="aset/image/bear.gif"></td>
	<td><img src="aset/image/bear.gif"></td>
	<td><img src="aset/image/bear.gif"></td>
	<script type="text/javascript">
		alert("Terima Kasih Sampai Jumpa Kembali.......... :) ");
		window.open("login ","_self");
	</script>
	