<title>menu</title>
<table  width="100%" height="100%" border="1" bgcolor="#444 ";>
<td align="center">
	<font size="+2" color="black" face="Showcard Gothic"><br>Selamat Datang <?php echo $this->session->userdata('nama'); ?></br></font> 
	<img  src="aset/image/welcome.gif" 	>
</td>
</table>
